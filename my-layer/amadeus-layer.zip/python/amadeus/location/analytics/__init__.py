from ._category_rated_areas import CategoryRatedAreas

__all__ = ['CategoryRatedAreas']
