from ._on_time import AirportOnTime

__all__ = ['AirportOnTime']
