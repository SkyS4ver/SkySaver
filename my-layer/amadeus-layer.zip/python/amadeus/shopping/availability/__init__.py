from ._flight_availabilities import FlightAvailabilities

__all__ = ['FlightAvailabilities']
